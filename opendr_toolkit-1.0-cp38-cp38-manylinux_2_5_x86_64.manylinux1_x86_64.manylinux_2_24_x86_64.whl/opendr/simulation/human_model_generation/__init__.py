from opendr.simulation.human_model_generation.pifu_generator_learner import PIFuGeneratorLearner

__all__ = ['PIFuGeneratorLearner']
