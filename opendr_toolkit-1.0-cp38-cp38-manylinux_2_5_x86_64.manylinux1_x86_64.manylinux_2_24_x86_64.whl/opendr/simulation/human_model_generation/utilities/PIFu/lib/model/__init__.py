from .BasePIFuNet import BasePIFuNet
from .VhullPIFuNet import VhullPIFuNet
from .ConvPIFuNet import ConvPIFuNet
from .HGPIFuNet import HGPIFuNet
from .ResBlkPIFuNet import ResBlkPIFuNet
