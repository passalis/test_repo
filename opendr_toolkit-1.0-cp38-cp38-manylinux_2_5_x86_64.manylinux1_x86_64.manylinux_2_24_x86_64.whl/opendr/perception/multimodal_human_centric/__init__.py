from opendr.perception.multimodal_human_centric.rgbd_hand_gesture_learner.rgbd_hand_gesture_learner import (
    RgbdHandGestureLearner,
    get_builtin_architectures,
)

__all__ = ['RgbdHandGestureLearner', 'get_builtin_architectures']
