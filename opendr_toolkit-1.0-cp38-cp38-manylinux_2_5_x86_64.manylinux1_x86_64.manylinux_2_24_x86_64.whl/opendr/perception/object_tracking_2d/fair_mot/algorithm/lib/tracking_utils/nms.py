# Copyright (c) Facebook, Inc. and its affiliates. All Rights Reserved.
from tracking_utils import _C

nms = _C.nms
# This function performs Non-maximum suppresion"""
