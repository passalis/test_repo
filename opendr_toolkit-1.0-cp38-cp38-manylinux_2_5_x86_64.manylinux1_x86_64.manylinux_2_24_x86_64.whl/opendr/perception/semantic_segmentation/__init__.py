from opendr.perception.semantic_segmentation.bisenet.bisenet_learner import BisenetLearner
from opendr.perception.semantic_segmentation.bisenet.CamVid import CamVidDataset

__all__ = ['BisenetLearner', 'CamVidDataset']
