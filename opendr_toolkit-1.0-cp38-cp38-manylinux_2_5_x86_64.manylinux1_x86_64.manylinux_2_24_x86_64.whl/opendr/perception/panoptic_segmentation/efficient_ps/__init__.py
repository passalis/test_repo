from opendr.perception.panoptic_segmentation.efficient_ps.efficient_ps_learner import EfficientPsLearner

__all__ = ['EfficientPsLearner']
