from opendr.perception.face_recognition.face_recognition_learner import FaceRecognitionLearner

__all__ = ['FaceRecognitionLearner']
