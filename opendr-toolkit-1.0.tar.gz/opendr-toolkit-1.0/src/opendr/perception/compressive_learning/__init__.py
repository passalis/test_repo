from opendr.perception.compressive_learning.multilinear_compressive_learning.multilinear_compressive_learner import (
    MultilinearCompressiveLearner, get_builtin_backbones, PRETRAINED_COMPRESSED_SHAPE)

__all__ = ['MultilinearCompressiveLearner', 'get_builtin_backbones', 'PRETRAINED_COMPRESSED_SHAPE']
