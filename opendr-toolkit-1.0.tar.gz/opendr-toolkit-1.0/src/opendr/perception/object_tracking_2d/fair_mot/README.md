# OpenDR 2D Object Tracking - FairMOT

This folder contains the OpenDR Learner class implemented for the 2D Object Tracking task. 

## Sources

Large parts of the Learner code are taken from [ifzhang/FairMOT](
https://github.com/ifzhang/FairMOT) (the folder is algorithm) with modifications to make them compatible with OpenDR specifications.
