## Engine Module

This module contains re-usable definitions of various classes needed to implement the core functionality of the OpenDR toolkit.
