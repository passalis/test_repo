from opendr.control.single_demo_grasp.training.single_demo_grasp_learner import SingleDemoGraspLearner

__all__ = ['SingleDemoGraspLearner']
